// ==UserScript==
// @name         Spy (spys.one)
// @namespace    http://N/A.net/
// @version      0.1
// @description  try to take over the world!
// @author       E.T.R.A
// @match        http://spys.one/free-proxy-list/CN/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    // Your code here...
	/* 变量声明 */

    var show_per_page
    var proxy_type_select

    /* 函数声明 */

    function Show_100_Type_socks() {

        show_per_page.value = "2";//2 对应的是每页100个

        proxy_type_select.value = "2";//2 对应的是每页100个

        proxy_type_select.onchange();//触发onchange事件

        show_per_page.onchange();//触发onchange事件

    }

    function Check_this_page(){

        /* 获取 |代理类型选择框| 和 |每页显示个数选择框| 对象 */

        show_per_page = document.getElementById("xpp");

        proxy_type_select = document.getElementById("xf5");

        /* 查看当前页面是否是 "|socks| 每页 |100| 个显示"，即页面已修改 */

        if(!(show_per_page.value == '2' && proxy_type_select.value == '2')){

            /* 当前页面不是所需页面，故进行修改 */

            Show_100_Type_socks()

        }

    }


	/* 加载完成后运行入口 */
    window.onload=function(){

        setTimeout(execute_my_script,2000)

    }
	/* 实际运行的函数 */
    function execute_my_script(){

        Check_this_page()

    }
})();